package com.example.restapi.validation.service;

public interface Authentication {
	
	public String isValid(String username,String password);

}
